from django.apps import AppConfig


class TvShowApp2Config(AppConfig):
    name = 'tv_show_app2'
