from django.apps import AppConfig


class NinjaGlodAppConfig(AppConfig):
    name = 'ninja_glod_app'
