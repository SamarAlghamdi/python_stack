from django.apps import AppConfig


class DojoNinjasAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dojo_ninjas_app'
