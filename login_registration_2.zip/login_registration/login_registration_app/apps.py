from django.apps import AppConfig


class LoginRegistrationAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'login_registration_app'
